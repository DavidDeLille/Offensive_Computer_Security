

int function1(int age, char *name) {
    int real_age = age+2;
    printf("Hi %s, I bet you are *really* %d years old ;)\n", name, real_age);

    return real_age;
}

int main(void) {
    function1(29, "Sally");
    return 0;
}



