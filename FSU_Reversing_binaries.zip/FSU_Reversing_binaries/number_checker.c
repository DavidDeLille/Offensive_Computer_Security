#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char buff[15];
    int user_guess;

    if (argc != 2) {
        printf("Oops, try again\n");
        return 1;
    }

    user_guess = atoi(argv[1]);

    if (user_guess <= 0 || user_guess >= 1000) {
        printf("Closer, try again\n");
        return 1;
    }

    if (user_guess % 47 == 0 && user_guess % 15 == 0) {
        // solution = 705
        // "r3v3rsing r0cks"
        buff[1] = '3';
        buff[13] = 'k';
        buff[3] = '3';
        buff[4] = 'r';
        buff[0] = 'r';
        buff[8] = 'g';
        buff[12] = 'c';
        buff[6] = 'i';
        buff[7] = 'n';
        buff[9] = ' ';
        buff[11] = '0';
        buff[5] = 's';
        buff[14] = 's';
        buff[2] = 'v';
        buff[10] = 'r';
        buff[15] = '\0';
        printf("Great job!\n");
        printf("The key = %s\n", buff);
    }
    return 0;
}
